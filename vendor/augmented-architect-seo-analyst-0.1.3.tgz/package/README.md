# SEO Analyst

A host-independent TypeScript agent built with the OpenAI Agents SDK. This private package contains no credentials, business identity, tenant IDs, Google property IDs, database clients, Next.js imports or persistence implementation.

## Integration

```ts
import { runSeoAnalysis } from '@augmented-architect/seo-analyst';
const result = await runSeoAnalysis(validatedBusinessConfig, authorizedReadOnlyTools, executionHost);
```

The host supplies a `ModelProvider`, validated public business context, read-only GA4/Search Console ports, approved website research, and external research. It must enforce tenant/property ownership before granting capabilities. Model-visible tools never receive credentials or database access. Progress and actual provider usage are returned through callbacks. Persistence belongs to the host.

Tools memoize one retrieval each. External research is limited to one injected request. The initial website adapter uses OpenAI Responses hosted `web_search`, low context, with at most one hosted tool call and traceable provider citations: https://developers.openai.com/api/docs/guides/tools-web-search . Untrusted retrieved content cannot authorize actions. Recommendations require owner review; no publication, scheduling, campaign or advertising capability is present.

## Execution budget

- Maximum five SDK model requests, 2,400 output tokens per request.
- Maximum 160,000 cumulative serialized input bytes (conservative host-visible input bound).
- One external research request; initial host caps that response at 1,600 output tokens and one hosted search call.
- 150-second run deadline; caller cancellation supported; no SDK/provider automatic retries.
- Hosted search internally retrieved context is provider-managed, not covered by the serialized-input byte count. Its actual token usage is retained separately. These are execution limits, not a guaranteed currency spend cap.
- No costs are inferred from token counts. Measured cost remains null unless an integration can supply verified billing information.

`npm test` runs the actual SDK against a mock transport. No paid calls or external side effects occur. `npm pack` produces the versioned deployable artifact.

## Future governed hosts

See [runtime contract](docs/runtime-contract.md). The SDK runner is an initial execution engine, not a replacement for an Agent Manager, access-package authority, scheduler, approval service or durable governance runtime.
