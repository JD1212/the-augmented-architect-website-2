# Content Strategist

Independent OpenAI Agents SDK editorial agent. `runContentStrategist(input, ports, host)` accepts the versioned approved assignment, verified source snapshots, structured reporting facts, business positioning and requested channels. The host supplies authorization and model execution. No business IDs, credentials, database, web framework, publishing or paid research implementation lives here.

Output is a substantive website draft, separately adapted LinkedIn post, an existing-page proposal or an explicit evidence request. Every result remains draft. Source reads use immutable authorized snapshots; model requests, input bytes, runtime and output are bounded, with no retries. Returned usage records provider tokens; measured cost stays unknown when not supplied by the provider.

Augment can implement the same tool ports, model provider, cancellation, progress, authorization and persistence around this package. No governance system is embedded here. The initial host is the website's private server adapter.

`npm ci`, `npm test`. Tests run the actual SDK against deterministic model fixtures. They never call a live model or publisher. Website release approval is separate from draft generation and exact revision approval.
