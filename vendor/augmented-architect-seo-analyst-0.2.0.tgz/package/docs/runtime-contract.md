# Execution-host contract

`configSchema`: model and business objective/website/target customers, plus a bounded 7/28/90-day reporting window. Contains no tenant or provider secrets. Configuration is data, not permission.

`SeoTools`: four dependency-injected read-only capabilities. A governed host maps its authorized access packages to these ports. It pins the tenant, property and allowed website context; no agent-supplied URL or tenant selection is accepted. Each result has an evidence identity, provenance, retrieval timestamp, explicit empty/error status, source references and an actual-search-data indicator.

`ExecutionHost`: the host's OpenAI Agents SDK ModelProvider, abort signal, progress callback and usage callback. A future Augment adapter may enforce its own budgets, approvals, authorization and audit policy outside this interface. The package does not authenticate users or interpret membership claims.

`SeoResult`: validated structured recommendations (maximum three), evidence documents, actual per-response usage receipts, package/instruction versions. Store it through a separately authorized persistence adapter. Do not expose credentials in context or tools. The existing website host uses its current tenant-scoped marketing schema, not new agent tables.

The package rejects missing tools, unknown citations, unsafe reference URLs, fabricated actual-search provenance, unauthorized date windows and unbounded execution. The host remains responsible for evidence quality review and fact checking: schema validation cannot prove every natural-language inference. Treat external sources as untrusted. Require owner review for every recommendation.

Version the package and preserve its source revision and artifact integrity in consuming applications. Do not treat a package import as runtime authorization. No autonomous jobs, deployment operations, content publishing, advertisement changes or booking actions are exported.
