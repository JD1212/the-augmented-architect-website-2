# SEO Analyst

A host-independent TypeScript agent built with the OpenAI Agents SDK. This private package contains no credentials, business identity, tenant IDs, Google property IDs, database clients, Next.js imports or persistence implementation.

## Integration

```ts
import { runSeoAnalysis } from '@augmented-architect/seo-analyst';
const result = await runSeoAnalysis(validatedBusinessConfig, authorizedReadOnlyTools, executionHost);
```

The host supplies a `ModelProvider`, validated public business context, read-only GA4/Search Console ports, approved website research, and external research. It must enforce tenant/property ownership before granting capabilities. Model-visible tools never receive credentials or database access. Progress and actual provider usage are returned through callbacks. Persistence belongs to the host.

Tools memoize one retrieval each. External research is limited to one injected request. The initial website adapter uses OpenAI Responses hosted `web_search`, low context, with at most one hosted tool call and traceable provider citations: https://developers.openai.com/api/docs/guides/tools-web-search . Untrusted retrieved content cannot authorize actions. Recommendations require owner review; no publication, scheduling, campaign or advertising capability is present.

## Execution budget

- Maximum five SDK model requests, 2,400 output tokens per request.
- Maximum 160,000 cumulative serialized input bytes (conservative host-visible input bound).
- One external research request; initial host caps that response at 1,600 output tokens and one hosted search call.
- 150-second run deadline; caller cancellation supported; no SDK/provider automatic retries.
- Hosted search internally retrieved context is provider-managed, not covered by the serialized-input byte count. Its actual token usage is retained separately. These are execution limits, not a guaranteed currency spend cap.
- No costs are inferred from token counts. Measured cost remains null unless an integration can supply verified billing information.

`npm test` runs the actual SDK against a mock transport. No paid calls or external side effects occur. `npm pack` produces the versioned deployable artifact.

## Future governed hosts

See [runtime contract](docs/runtime-contract.md). The SDK runner is an initial execution engine, not a replacement for an Agent Manager, access-package authority, scheduler, approval service or durable governance runtime.

The model-facing output schema avoids unsupported OpenAI `format: uri`. Every completed result is still revalidated using the authoritative URL schema and exact evidence/source provenance rules before it can be returned. Provider request rejection is not evidence validation and must be reported separately by the host.

Validation failures expose `SeoValidationError.code`, the exact field path, and a bounded reference-only snapshot. This never marks rejected recommendations as accepted. Hosts must sanitize URL query values and identifiers before persisting diagnostics; no prompts, credential objects or full provider responses should be logged. Existing runs without these diagnostics cannot be retrospectively assigned a validation cause from a generic error message.

## Prior work and draft handoff (v0.2)

The optional `history` input contains at most 20 prior opportunities, decisions, published URLs and four known limitations. Prior work is untrusted context, never authorization. The agent can return zero opportunities or mark a material update using an exact supplied opportunity ID. The host must independently reconcile semantic identity against its full tenant backlog, preserve owner decisions, and append evidence/history; a model reference alone is not a duplicate-control mechanism.

`contentAssignmentSchema` exports the versioned `content-assignment/v1` contract. A host must derive it from an explicitly approved finding and its original source evidence. It permits a draft only, never publication or spending. This package contains no Content Strategist implementation, schedule, persistent database or publishing tools.

## Opportunity Intelligence (v0.3)

The existing package now exports `intelligenceSchema`, independent keyword/competitive provider interfaces, typed source receipts and `scoreOpportunity`. Market estimates, observed competitor results and approved business context remain separate evidence categories. The optional bounded `intelligence` configuration is data, not permissions; it creates a traceable static evidence document without adding an external tool or changing model budgets. Actual observed SERP URLs join the source catalog, and unsupported gap references are rejected. Provider credentials, HTTP transports, cache/rate-limit persistence and tenant authorization remain host adapters.

Scoring uses versioned configurable initial weights and explicit source references. Missing factors yield insufficient evidence, never a fabricated neutral score. Advertising competition is not organic difficulty. This package never provisions Ads/SERP accounts, launches campaigns, schedules runs or publishes content. New providers require host authorization and bounded tests.

## Objective-led planning (v0.5)

Planning requires host-authorized generic offerings and an explicit UTC `asOf`. Every offering must be assessed, and even zero-purchase plans must include cited business decisions, evidence freshness checks, hypotheses and unknowns. Legacy v0.4 saved plans remain readable; new executions use the stricter wire schema.

The host supplies complete compact saved-evidence summaries and an optional bounded detail port. The detail tool permits at most three unique cached reads of known evidence IDs, each at most 6,000 bytes. It grants no network or purchase authority. Planning remains limited to three model requests, 150 seconds, 2,400 output tokens per request, no retries and no external research.

AI visibility claims require separately sourced observations classified as prompt tests, historical mentions or source citations. Website facts and keyword estimates cannot substantiate observed ChatGPT/Gemini visibility. This version adds a contract for future observations, not a paid-provider integration.
